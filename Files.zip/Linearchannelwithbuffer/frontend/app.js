document.addEventListener('DOMContentLoaded', function() {
    const videoPlayer = document.getElementById('video-player');
    const seekBar = document.getElementById('seek-bar');
    const liveBtn = document.getElementById('live-btn');

    let isLive = true;  // Assume initially live
    const hls = new Hls();

    // Function to load and play the stream
    function loadStream(m3u8Url) {
        if (Hls.isSupported()) {
            hls.loadSource(m3u8Url);
            hls.attachMedia(videoPlayer);
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                videoPlayer.play();
            });
        } else if (videoPlayer.canPlayType('application/vnd.apple.mpegurl')) {
            videoPlayer.src = m3u8Url;
            videoPlayer.addEventListener('loadedmetadata', function() {
                videoPlayer.play();
            });
        } else {
            console.error('HLS not supported in this browser');
        }
    }

    // Function to handle seeking
    seekBar.addEventListener('input', function() {
        const seekTime = videoPlayer.duration * (seekBar.value / 100);
        videoPlayer.currentTime = seekTime;
    });

    // Function to toggle between live and recorded
    liveBtn.addEventListener('click', function() {
        if (!isLive) {
            loadStream('your-live-m3u8-url');
            liveBtn.textContent = 'Live';
        } else {
            // Load recorded content (last 45 minutes)
            loadStream('your-recorded-m3u8-url');
            liveBtn.textContent = 'Recorded';
        }
        isLive = !isLive;
    });

    // Function to update seekbar and check live status periodically
    setInterval(function() {
        if (!videoPlayer.paused && !videoPlayer.ended) {
            const currentTime = videoPlayer.currentTime;
            const duration = videoPlayer.duration;
            const progress = (currentTime / duration) * 100;
            seekBar.value = progress;
        }
    }, 1000); // Update every second

    // Initial load
    loadStream('https://d2c664cho7ay77.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-jv86x14at6fnu/playlist.m3u8');  // Load live stream initially
});
