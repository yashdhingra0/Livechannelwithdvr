const express = require('express');
const app = express();
const path = require('path');
const cors = require('cors');
const app = express();

// Enable CORS for all requests
app.use(cors());

// Serve static files from the 'frontend' directory
app.use(express.static(path.join(__dirname, '../frontend')));

// Endpoint to handle M3U8 URL input and return it
app.get('/m3u8', (req, res) => {
    const { m3u8Url } = req.query;
    // Perform any validation or processing here
    // Example: Return the M3U8 URL directly
    res.json({ m3u8Url });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
