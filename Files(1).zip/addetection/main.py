import m3u8
import requests

def load_m3u8(url):
    return m3u8.load(url)

def check_ad_markers(segments):
    markers = ['EXT-X-DISCONTINUITY', 'EXT-X-CUE-OUT', 'EXT-X-CUE-IN']
    issues = []
    for segment in segments:
        if not any(marker in segment.uri for marker in markers):
            issues.append(f"Missing ad marker in {segment.uri}")
    return issues

def check_ad_duration(segments, expected_duration=15):
    issues = []
    for segment in segments:
        if 'ad' in segment.uri:
            duration = float(segment.duration)
            if duration != expected_duration:
                issues.append(f"Ad {segment.uri} has incorrect duration: {duration} seconds")
    return issues

def check_segment_accessibility(segments):
    issues = []
    for segment in segments:
        response = requests.get(segment.uri)
        if response.status_code != 200:
            issues.append(f"Segment {segment.uri} is not accessible, HTTP status code: {response.status_code}")
    return issues

def check_buffering_issues(segments, max_size_mb=5):
    issues = []
    for segment in segments:
        response = requests.head(segment.uri)
        size_mb = int(response.headers.get('content-length', 0)) / (1024 * 1024)
        if size_mb > max_size_mb:
            issues.append(f"Segment {segment.uri} is too large: {size_mb:.2f} MB")
    return issues

def check_ad_sequence(segments):
    issues = []
    ad_segments = [seg for seg in segments if 'ad' in seg.uri]
    for i in range(len(ad_segments) - 1):
        current_ad_num = int(ad_segments[i].uri.split('ad')[1].split('.')[0])
        next_ad_num = int(ad_segments[i + 1].uri.split('ad')[1].split('.')[0])
        if next_ad_num != current_ad_num + 1:
            issues.append(f"Ad sequence error between {ad_segments[i].uri} and {ad_segments[i + 1].uri}")
    return issues

def check_ad_looping(segments):
    issues = []
    ad_uris = [seg.uri for seg in segments if 'ad' in seg.uri]
    seen = set()
    for uri in ad_uris:
        if uri in seen:
            issues.append(f"Ad {uri} is repeated")
        seen.add(uri)
    return issues

def check_mismatched_codecs(segments, expected_codec='h264'):
    issues = []
    for segment in segments:
        if 'ad' in segment.uri:
            # Simulating codec check
            actual_codec = 'h264'  # Placeholder, replace with actual codec detection logic
            if actual_codec != expected_codec:
                issues.append(f"Ad {segment.uri} has mismatched codec: {actual_codec}")
    return issues

def check_ad_placement(segments):
    issues = []
    for i in range(1, len(segments)):
        if 'ad' in segments[i].uri and 'ad' not in segments[i-1].uri and 'ad' not in segments[i+1].uri:
            issues.append(f"Ad {segments[i].uri} placed in the middle of content")
    return issues

def check_ad_skipping(segments):
    issues = []
    for segment in segments:
        if 'ad' in segment.uri and 'EXT-X-KEY:METHOD=NONE' in segment.uri:
            issues.append(f"Ad {segment.uri} is not encrypted, can be skipped")
    return issues

def check_ad_relevance(segments, content_rating='G'):
    issues = []
    for segment in segments:
        if 'ad' in segment.uri:
            # Simulating relevance check
            ad_rating = 'G'  # Placeholder, replace with actual ad rating logic
            if ad_rating != content_rating:
                issues.append(f"Ad {segment.uri} is not relevant for content rating {content_rating}")
    return issues

def perform_checks(url):
    m3u8_obj = load_m3u8(url)
    segments = m3u8_obj.segments

    checks = [
        ("Missing Ad Markers", check_ad_markers),
        ("Incorrect Ad Duration", check_ad_duration),
        ("Segment Accessibility", check_segment_accessibility),
        ("Buffering Issues", check_buffering_issues),
        ("Ad Sequence Errors", check_ad_sequence),
        ("Ad Looping", check_ad_looping),
        ("Mismatched Codecs", check_mismatched_codecs),
        ("Incorrect Ad Placement", check_ad_placement),
        ("Ad Skipping", check_ad_skipping),
        ("Ad Content Relevance", check_ad_relevance)
    ]

    results = {}
    for name, check in checks:
        issues = check(segments)
        if issues:
            results[name] = issues
        else:
            results[name] = ["Pass - No issues found"]

    return results

def print_results(results):
    for check, issues in results.items():
        print(f"{check}:")
        for issue in issues:
            print(f"  - {issue}")

# Example usage
url = 'https://drive.google.com/uc?export=download&id=1wZA6t2kcYpeXJfDm18NqJEd4FFlcWYRd'
results = perform_checks(url)
print_results(results)
